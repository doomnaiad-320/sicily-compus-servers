import request from '~/api/request';
import { formatMonthDayTime, getTimestamp } from '~/utils/date';

// 用户模式的状态tabs
const USER_STATUS_TABS = [
  { label: '全部', value: 'all' },
  { label: '待支付', value: 'unpaid' },
  { label: '待接单', value: 'pending' },
  { label: '服务中', value: 'in_progress' },
  { label: '待确认', value: 'waiting_confirm' },
  { label: '已完成', value: 'completed' },
  { label: '已取消', value: 'cancelled' },
];

// 兼职者模式的状态tabs
const WORKER_STATUS_TABS = [
  { label: '全部', value: 'all' },
  { label: '服务中', value: 'in_progress' },
  { label: '待确认', value: 'waiting_confirm' },
  { label: '已完成', value: 'completed' },
  { label: '已取消', value: 'cancelled' },
];

Page({
  data: {
    role: 'user',
    current: 'all',
    list: [],
    available: [],
    displayList: [], // 用于展示的筛选后列表
    view: 'mine', // mine | available (worker only)
    loading: true,
    statusTabs: USER_STATUS_TABS, // 传递给模板
  },

  onShow() {
    this.init();
  },

  async init() {
    this.setData({ loading: true });
    try {
      const user = await request('/api/user/info', 'GET');
      const role = user.currentRole || 'user';
      let primary = [];
      let available = [];
      if (role === 'worker') {
        // 兼职者模式：只显示接的订单
        [primary, available] = await Promise.all([
          request('/api/order?role=worker', 'GET'),
          request('/api/order?role=worker&view=available', 'GET'),
        ]);
      } else {
        // 用户模式：只显示发布的订单
        primary = await request('/api/order', 'GET');
      }
      this.setData({
        role,
        list: primary,
        available,
        statusTabs: role === 'worker' ? WORKER_STATUS_TABS : USER_STATUS_TABS,
        current: 'all', // 切换角色时重置为全部
        loading: false,
      });
      this.updateDisplayList();
    } catch (e) {
      this.setData({ loading: false });
      wx.showToast({ title: e?.message || '加载失败', icon: 'none' });
    }
  },

  onTabChange(e) {
    this.setData({ current: e.detail.value });
    this.updateDisplayList();
  },

  onViewChange(e) {
    this.setData({ view: e.detail.value });
    this.updateDisplayList();
  },

  // 更新展示列表
  updateDisplayList() {
    const { current, list, available, view, role } = this.data;
    const source = role === 'worker' && view === 'available' ? available : list;
    const filtered = current === 'all' ? source : (source || []).filter((o) => o.status === current);
    const displayList = (filtered || []).map((o) => ({
      ...o,
      expectedTime: o.expectedTime ? formatMonthDayTime(o.expectedTime) : '',
      createdAt: o.createdAt ? formatMonthDayTime(o.createdAt) : '',
      statusTag: this.statusTag(o.status),
    }));
    this.setData({ displayList });
  },

  statusTag(status) {
    const map = {
      unpaid: { text: '待支付', theme: 'warning' },
      pending: { text: '待接单', theme: 'primary' },
      in_progress: { text: '服务中', theme: 'primary' },
      waiting_confirm: { text: '待确认', theme: 'warning' },
      completed: { text: '已完成', theme: 'success' },
      cancelled: { text: '已取消', theme: 'default' },
      aftersale: { text: '售后中', theme: 'danger' },
      appealing: { text: '申诉中', theme: 'danger' },
    };
    return map[status] || { text: status, theme: 'default' };
  },

  goDetail(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({ url: `/pages/order-detail/index?id=${id}` });
  },

  sortByTimeAsc() {
    const { list, available } = this.data;
    const sortFn = (a, b) => getTimestamp(a.createdAt) - getTimestamp(b.createdAt);
    this.setData({
      list: [...(list || [])].sort(sortFn),
      available: [...(available || [])].sort(sortFn),
    });
    this.updateDisplayList();
  },

  sortByTimeDesc() {
    const { list, available } = this.data;
    const sortFn = (a, b) => getTimestamp(b.createdAt) - getTimestamp(a.createdAt);
    this.setData({
      list: [...(list || [])].sort(sortFn),
      available: [...(available || [])].sort(sortFn),
    });
    this.updateDisplayList();
  },
});
